# HIH FIFA World Cup 2026 V4

GitHub Pages hosts `index.html`. GitHub Actions fetches score data server-side and writes results to Firebase Realtime Database.

Files:
- `index.html` — your GitHub Pages site file.
- `.github/workflows/sync-worldcup-scores.yml` — scheduled score sync every 10 minutes.
- `scripts/sync-scores.js` — Node.js sync script using football-data.org + Firebase Admin SDK.
- `scripts/worldcup-matches.json` — local match map used to match provider fixtures to your app match IDs.
- `firebase-rules-v4.json` — Realtime Database rules for the app.
